﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EyeClinic.Models;
using System.Data.Entity;
using System.Net.Mail;
using System.Net;
namespace EyeClinic.Controllers
{
    public class DashBoardController : Controller
    {
        public static int roll = 0;
        Eyes con = new Eyes();
        // GET: DashBoard
        public ActionResult AdminDash()
        {
            return View();
        }
        public ActionResult UserDash()
        {
            return View();
        }
        public ActionResult ClinicDash()
        {
            return View();
        }
        public ActionResult ClinicApproval()
        {
            return View(con.Clinics.Where(m => m.Status == null).ToList());
        }
        public ActionResult UserApproval()
        {
            return View(con.Users.Where(m => m.Status == null).ToList());
        }
        public ActionResult ClinicActive(int id)
        {
            var g = con.Clinics.Find(id);
            g.Status = "Active";
            con.SaveChanges();
            return RedirectToAction("ClinicApproval");
        }
        public ActionResult UserActive(int id)
        {
            var g = con.Users.Find(id);
            g.Status = "Active";
            con.SaveChanges();
            return RedirectToAction("UserApproval");
        }
        public ActionResult Cliniclist()
        {
            return View(con.Clinics.Where(m => m.Status != null).ToList());
        }
        [HttpPost]
        public ActionResult Cliniclist(string ser)
        {
            if (ser != "")
            {
                return View(con.Clinics.Where(m => m.Status != null && m.City.Contains(ser)).ToList());
            }
            else
            {
                return View(con.Clinics.Where(m => m.Status != null).ToList());
            }
        }
        public ActionResult Userlist()
        {
            return View(con.Users.Where(m => m.Status != null).ToList());
        }
        public ActionResult ClinicProfile()
        {
            int j = Convert.ToInt32(TempData["Pro"].ToString());
            TempData.Keep();
            return View(con.Clinics.Find(j));
        }
        [HttpPost]
        public ActionResult ClinicProfile(Clinic c)
        {
            c.Status = "Active";
            con.Entry(c).State = EntityState.Modified;
            con.SaveChanges();
            return RedirectToAction("ClinicProfile");
        }

        public ActionResult UserProfile()
        {
            int j = Convert.ToInt32(TempData["Pro"].ToString());
            TempData.Keep();
            return View(con.Users.Find(j));
        }
        [HttpPost]
        public ActionResult UserProfile(User c)
        {
            c.Status = "Active";
            con.Entry(c).State = EntityState.Modified;
            con.SaveChanges();
            return RedirectToAction("UserProfile");
        }

        public ActionResult ClinicList1()
        {
            return View(con.Clinics.Where(m => m.Status != null).ToList());
        }
        [HttpPost]
        public ActionResult ClinicList1(string ser)
        {
            if (ser != "")
            {
                return View(con.Clinics.Where(m => m.Status != null && m.City.Contains(ser)).ToList());
            }
            else
            {
                return View(con.Clinics.Where(m => m.Status != null).ToList());
            }
        }

        public ActionResult Userlist1()
        {
            return View(con.Users.Where(m => m.Status != null).ToList());
        }

        public ActionResult guidelines()
        {
            return View();
        }
        [HttpPost]
        public ActionResult guidelines(EyeGuideline s)
        {
            if (ModelState.IsValid)
            {
                con.EyeGuidelines.Add(s);
                con.SaveChanges();
                TempData["msg"] = "<script>alert('Added Successfully!')</script>";
                return RedirectToAction("ClinicDash", "Dashboard");
            }
            else
            {
                return View();
            }
        }
        public ActionResult Guidelist()
        {
            return View(con.EyeGuidelines.ToList());
        }
        [HttpPost]
        public ActionResult Guidelist(string i)
        {
            return View(con.EyeGuidelines.Where(m => m.GN.Contains(i)).ToList());
        }
        public ActionResult BookAppoint()
        {
            ViewBag.doc = con.Clinics.Select(m => m.DN).ToList();
            return View();
        }
        [HttpPost]
        public ActionResult BookAppoint(Booking s)
        {
            int j = Convert.ToInt32(TempData["Pro"].ToString());
            s.UI = j;
            roll++;
            s.BI = "Eye-Token-" + roll.ToString();
            TempData.Keep();
            con.Bookings.Add(s);
            con.SaveChanges();
            return RedirectToAction("bookinglist");


        }
        public ActionResult bookinglist()
        {
            int j = Convert.ToInt32(TempData["Pro"].ToString());
            TempData.Keep();
            var k = con.Users.Find(j);
            return View(con.Bookings.Where(m => m.UI.Equals(k.Id)).ToList());
        }

        public ActionResult bookinglist1()
        {

            return View(con.Bookings.Where(m => m.Status == null).ToList());
        }
        public ActionResult accept(int i)
        {
            var g = con.Bookings.Find(i);
            g.Status = "Accept";
            con.SaveChanges();
            return RedirectToAction("bookinglist1");
        }
        public ActionResult fb()
        {
            return View();
        }
        [HttpPost]
        public ActionResult fb(FeedBack k)
        {
            int j = Convert.ToInt32(TempData["Pro"].ToString());
            TempData.Keep();
            var d = con.Users.Find(j);
            k.UI = d.Id;
            k.UN = d.FN;
            k.UM = d.Mail;
            con.FeedBacks.Add(k);
            con.SaveChanges();
            return RedirectToAction("UserDash");
        }
        public ActionResult fbl()
        {
            return View(con.FeedBacks.ToList());
        }
        public ActionResult fbl1()
        {
            return View(con.FeedBacks.ToList());
        }
        public ActionResult Forgot()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Forgot(Login s)
        {
            Random k1 = new Random();
            int pass = k1.Next(100000, 500000);

            try
            {
                int k = con.Clinics.Where(m => m.Mail.Equals(s.email)).Select(m => m.Id).FirstOrDefault();
                var data = con.Clinics.Find(k);
                data.Pass = pass.ToString();
                data.ConPass = pass.ToString();
                con.SaveChanges();
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress("vijayproject2023@gmail.com");
                message.To.Add(new MailAddress(s.email));
                message.Subject = "New Account Password";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = "New Password :- " + pass;
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("vijayproject2023@gmail.com", "lnopyipnkzjwnqmq");
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
                return RedirectToAction("ClinicLogin", "login");
            }
            catch (Exception e)
            {

            }
            return View();

        }



        public ActionResult Forgot1()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Forgot1(Login s)
        {
            Random k1 = new Random();
            int pass = k1.Next(100000, 500000);

            try
            {
                int k = con.Users.Where(m => m.Mail.Equals(s.email)).Select(m => m.Id).FirstOrDefault();
                var data = con.Users.Find(k);
                data.Pass = pass.ToString();
                data.ConPass = pass.ToString();
                con.SaveChanges();
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress("vijayproject2023@gmail.com");
                message.To.Add(new MailAddress(s.email));
                message.Subject = "New Account Password";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = "New Password :- " + pass;
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("vijayproject2023@gmail.com", "lnopyipnkzjwnqmq");
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
                return RedirectToAction("userLogin", "login");
            }
            catch (Exception e)
            {

            }
            return View();


           
           
        }


        public ActionResult Forgot2()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Forgot2(Login s)
        {
            Random k1 = new Random();
            int pass = k1.Next(100000, 500000);

            try
            {
                int k = con.CommonLogins.Where(m => m.UN.Equals(s.email)).Select(m => m.Id).FirstOrDefault();
                var data = con.CommonLogins.Find(k);
                data.Pass = pass.ToString();
                data.ConPass = pass.ToString();
                con.SaveChanges();
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress("vijayproject2023@gmail.com");
                message.To.Add(new MailAddress(s.email));
                message.Subject = "New Account Password";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = "New Password :- " + pass;
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("vijayproject2023@gmail.com", "lnopyipnkzjwnqmq");
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
                return RedirectToAction("AdminLogin", "login");
            }
            catch (Exception e)
            {

            }
            return View();

          
           
        }

    }
}