﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EyeClinic.Models;

namespace EyeClinic.Controllers
{
    public class LoginController : Controller
    {
        Eyes con = new Eyes();
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(Login s)
        {
            int cou = con.CommonLogins.Where(m => m.UN.Equals(s.email) && m.Pass.Equals(s.PSD)).Count();
            if (ModelState.IsValid)
            {
                if (cou != 0)
                {
                    TempData["msg"] = "<script>alert('Account Login Successfully')</script>";
                    return RedirectToAction("dash", "Home");
                }
                else
                {
                    TempData["msg"] = "<script>alert('Login Failed Due to Incorrect Password')</script>";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        public ActionResult ClinicAccount()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ClinicAccount(CommonLogin C)
        {
            if (ModelState.IsValid)
            {
                con.CommonLogins.Add(C);
                con.SaveChanges();
                TempData["msg"] = "<script>alert('Account Created Successfully')</script>";
                return RedirectToAction("AdminLogin", "Login");
            }
            else
            {
                return View();
            }
        }

        public ActionResult AdminAccount()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminAccount(Login s)
        {
            if (ModelState.IsValid)
            {
                if (s.email == "admin@gmail.com" && s.PSD == "admin123")
                {
                    TempData["msg"] = "<script>alert('Account Login Successfully')</script>";
                    return RedirectToAction("AdminDash", "DashBoard");
                }
                else
                {
                    TempData["msg"] = "<script>alert('Login Failed Due to Incorrect Password')</script>";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }


        public ActionResult UserLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UserLogin(Login s)
        {
            int cou = con.Users.Where(m => m.Mail.Equals(s.email) && m.Pass.Equals(s.PSD) && m.Status=="Active").Count();
            if (ModelState.IsValid)
            {
                if (cou != 0)
                {
                    TempData["Pro"] = con.Users.Where(m => m.Mail.Equals(s.email) && m.Pass.Equals(s.PSD) && m.Status == "Active").Select(m => m.Id).FirstOrDefault();
                    TempData["msg"] = "<script>alert('Account Login Successfully')</script>";
                    return RedirectToAction("UserDash", "Dashboard");
                }
                else
                {
                    TempData["msg"] = "<script>alert('Login Failed Due to Incorrect Password')</script>";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        public ActionResult AddUserAccount()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddUserAccount(User C)
        {
            if (ModelState.IsValid)
            {
                con.Users.Add(C);
                con.SaveChanges();
                TempData["msg"] = "<script>alert('Account Created Successfully')</script>";
                return RedirectToAction("UserLogin", "Login");
            }
            else
            {
                return View();
            }
        }
        public ActionResult ClinicLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ClinicLogin(Login s)
        {
            int cou = con.Clinics.Where(m => m.Mail.Equals(s.email) && m.Pass.Equals(s.PSD) && m.Status == "Active").Count();
            if (ModelState.IsValid)
            {
                if (cou != 0)
                {
                    TempData["Pro"] = con.Clinics.Where(m => m.Mail.Equals(s.email) && m.Pass.Equals(s.PSD) && m.Status == "Active").Select(m => m.Id).FirstOrDefault();
                    TempData["msg"] = "<script>alert('Account Login Successfully')</script>";
                    return RedirectToAction("ClinicDash", "Dashboard");
                }
                else
                {
                    TempData["msg"] = "<script>alert('Login Failed Due to Incorrect Password')</script>";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        public ActionResult AddClinicLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddClinicLogin(Clinic C)
        {
            if (ModelState.IsValid)
            {
                con.Clinics.Add(C);
                con.SaveChanges();
                TempData["msg"] = "<script>alert('Account Created Successfully')</script>";
                return RedirectToAction("ClinicLogin", "Login");
            }
            else
            {
                return View();
            }
        }
    }
}