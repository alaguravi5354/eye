﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Data.Entity;
using System.Web;

namespace EyeClinic.Models
{
    public class Eye
    {


    }
    public class Login
    {
        [Required, Display(Name = "UserName"), EmailAddress]
        public string email { get; set; }

        [Required, Display(Name = "Password")]
        public string PSD { get; set; }
    }
    public class CommonLogin
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "UserName"), Required, EmailAddress]
        public string UN { get; set; }

        [Display(Name = "Password"), Required]
        public string Pass { get; set; }

        [Display(Name = "Confirmation Password"), Required]
        public string ConPass { get; set; }

        [Display(Name = "Mobile"), Required]
        public Int64 Mob { get; set; }

        [Display(Name = "City"), Required]
        public string City { get; set; }

    }
    public class Clinic
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Clinic Name"), Required]
        public string CN { get; set; }

        [Display(Name = "Doctor Name"), Required]
        public string DN { get; set; }

        [Display(Name = "In Time"), Required]
        public string ITime { get; set; }

        [Display(Name = "Out Time"), Required]
        public string OTime { get; set; }

        [Display(Name = "Mail Id"), Required, EmailAddress]
        public string Mail { get; set; }

        [Display(Name = "Password"), Required]
        public string Pass { get; set; }

        [Display(Name = "Confirmation Password"), Required]
        public string ConPass { get; set; }

        [Display(Name = "Mobile"), Required]
        public Int64 Mob { get; set; }

        [Display(Name = "City"), Required]
        public string City { get; set; }

        [Display(Name = "Account Status")]
        public string Status { get; set; }

    }
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "First Name"), Required]
        public string FN { get; set; }

        [Display(Name = "Mail Id"), Required, EmailAddress]
        public string Mail { get; set; }

        [Display(Name = "Password"), Required]
        public string Pass { get; set; }

        [Display(Name = "Confirmation Password"), Required]
        public string ConPass { get; set; }

        [Display(Name = "Mobile"), Required]
        public Int64 Mob { get; set; }

        [Display(Name = "City"), Required]
        public string City { get; set; }

        [Display(Name = "Account Status")]
        public string Status { get; set; }

    }
    public class EyeGuideline
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Guideline Number"), Required]
        public string GN { get; set; }

        [Display(Name = "Problem"), Required]
        public string Pro { get; set; }

        [Display(Name = "Guidelines"), Required]
        public string GL { get; set; }

    }
    public class Booking
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Booking Id")]
        public string BI { get; set; }

        [Display(Name = "User ID")]
        public int UI { get; set; }

        [Display(Name = "Booking Date"), Required]
        public string BD { get; set; }

        [Display(Name = "Booking Time"), Required]
        public string BT { get; set; }

        [Display(Name = "Doctor Name"), Required]
        public string DN { get; set; }

        [Display(Name = "Problem"), Required]
        public string Pro { get; set; }

        [Display(Name = "Appointment Status")]
        public string Status { get; set; }
    }
    public class FeedBack
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "User ID"), Required]
        public int UI { get; set; }

        [Display(Name = "User Name"), Required]
        public string UN { get; set; }

        [Display(Name = "User Mail"), Required]
        public string UM { get; set; }

        [Display(Name = "FeedBack"), Required]
        public string FB { get; set; }

    }
    public class Eyes : DbContext
    {
        public DbSet<CommonLogin> CommonLogins { get; set; }
        public DbSet<Clinic> Clinics { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<EyeGuideline> EyeGuidelines { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<FeedBack> FeedBacks { get; set; }
    }

}