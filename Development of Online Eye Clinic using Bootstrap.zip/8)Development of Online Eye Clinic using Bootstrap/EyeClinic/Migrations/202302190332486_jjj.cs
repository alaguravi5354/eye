﻿namespace EyeClinic.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class jjj : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.FeedBacks", "UN", c => c.String(nullable: false));
            AlterColumn("dbo.FeedBacks", "UM", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.FeedBacks", "UM", c => c.Int(nullable: false));
            AlterColumn("dbo.FeedBacks", "UN", c => c.Int(nullable: false));
        }
    }
}
